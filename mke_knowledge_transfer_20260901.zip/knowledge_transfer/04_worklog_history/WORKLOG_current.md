# MKE Supply-Chain — Work Log & Decision Journal

**Purpose:** a durable, append-only record of the work — *what was asked, what we decided, what we built, and
why* — so the history survives chat compaction and new sessions. The chat transcript is NOT a reliable record
(this project already lost its earliest turns to compaction). **Standing practice: after every accepted piece
of work, append an entry here** (date, the ask in the user's words, decision, artifacts, evidence, follow-ups).

Build logs hold *how a thing was built* (RUNG2_BUILDLOG, P1FLOW_BUILDLOG, P1_SLICE_BUILDLOG). This log holds
the *trail of intent and decisions* across the whole engagement. Reconstructed from the session compaction
summary + artifacts on 2026-08-31; entries after that were logged live.

---

## Phase 0 — Understanding & data stories (earlier session; reconstructed)
- **Ask (trail):** understand MKE supply-chain data by P1–P4; build ID-anchored data stories (positive/
  negative, anti-patterns, hidden patterns, lineage); solution architecture; an interactive HTML dashboard;
  a session log.
- **Built:** the full `data_understanding/data_stories/` library (S1–S9, G, R, V, T, C, RW, LG, EM, N, O, P,
  AP anti-patterns, HOP/STATE/QTY, GEO, CAUSES, IMPACT, lineage, catalog + synthesis), a solution
  architecture capstone, an interactive HTML dashboard.
- **Key decision:** `prod_edw.fact.purchase_receipt_line` is the P1 receipt source (the raw-Oracle crosswalk
  "blocker" dissolved) — `KEY_FINDING_receipt_source.md`.

## Phase 1 — P1 vertical slice (Rung 1)
- **Ask:** "what should be our next step?" → build the P1 slice; "source is read only… we will scale to the
  last 8 weeks… design so we can load the whole year… step by step."
- **Decision:** scale-aware rungs (1 item → all items → full year); READ-ONLY prod; writes to
  `sandbox_operations.po_management.p1slice_*`; develop in workspace, promote later.
- **Built:** `p1slice_planned_weekly / actuals_weekly / plan_vs_actual` (gold, 8 rows hero item), reconciled
  (receipt tie-out exact; semi-additive 538,116-vs-83,254 guard). Notebook + `P1_SLICE_BUILDLOG.md`.
- **Correction:** notebook SQL first rendered as markdown (each SQL must be its own cell) — user flagged; fixed.

## Phase 2 — Native AI/BI (Lakeview) dashboard, Rung 1
- **Ask:** "Build the native Lakeview dashboard on p1slice_plan_vs_actual." Then a chain of "no data" / "empty
  framework" / "go to docs" pushes.
- **Root causes fixed (now the fastpath skill):** widget query must be named `main_query`; no functions in
  widget expressions (push ABS/CASE into dataset SELECT); missing comma between queryLines breaks the dataset;
  filters on a global-filters page; % on 0–100 uses number-plain+suffix.
- **Built:** Rung-1 dashboard (ID 01f1a504e3a31d6097591184469039b4) + `lakeview-dashboard-fastpath` skill +
  memory. **Lesson:** copy known-good widget JSON, TEST the concatenated dataset query via CLI before deploy.

## Phase 3 — Rung 2 (all items) + multi-org 2120
- **Ask:** "work with org 2012 for Rung 2 … do not delete current ones, create new assets"; "think creatively
  on what questions the dashboard can answer … tackle the data_stories"; "what if I add more orgs — can the
  query/dashboard cater to it?"; "there was one more org (2120) — let's go with the recommendation."
- **Decisions:** drop the item filter (same SQL proves generalization — hero item numbers identical R1↔R2);
  org→plan mapping (2120→Mexico plan, else Global) with a single predicate to kill the 2120 double-count.
- **Built:** `rung2_planned_weekly / actuals_weekly / plan_vs_actual` (297,211 rows = distinct item×org×week),
  Rung-2 dashboard (ID 01f1a50aed891d5c85b5e64b2c3c5d5b) — org-aware, 6 pages. `RUNG2_BUILDLOG.md`.
- **Corrections caught by self-review:** "no-data" band was really "Unplanned (no plan)"; color/label
  inversion fixed by pinning semantic colors; %/$ column mislabels fixed.

## Phase 4 — "orgs are not interchangeable" (2120 validation)
- **Ask:** "we can't blindly say all orgs behave the same … find NEW scenarios for the new org, validate the
  identified ones, derive learnings + data-model changes, use subagents, log their activities."
- **Method:** 2 logged subagents (A: validate scenarios on 2120; B: hunt new 2120 scenarios) + **I
  re-verified every load-bearing number myself.**
- **Findings:** all 7 scenarios apply but behave differently → **thresholds must be org-specific**; 3 NEW
  verified findings (planner concentration 6 vs 92; 41% Mexico-exclusive SKUs; net-receiving pattern).
- **Correction:** subagents' "inverted bias" was refuted by a row-sign test — both orgs OVER-plan, 2012 ~5×
  harder (fixed in artifacts + memory).
- **Built:** `data_stories/org2120_validation/` INDEX + A + B + C (synthesis w/ 5 data-model changes).
  Memory: [[mke-orgs-are-not-interchangeable]].

## Phase 5 — More dashboard stories, scale-to-N-orgs
- **Ask:** "can we tell more stories with the new info … tomorrow there might be many orgs, we won't build
  separate dashboards … show contrast … but one can't say until they see the data … scope for tomorrow is
  these two orgs."
- **Decision:** every story widget GROUPS BY org (auto-renders new orgs); contrast in RELATIVE terms
  (%, ratios, per-item, percentiles) so a small org is comparable; scorecard table = the N-org backbone.
- **Built:** dashboard page "5 · Cross-Org Contrast" (scorecard, overage bar, variance-percentile grouped
  bar, lean-yet-green scatter, planner concentration, SKU shared/exclusive, scale context) + 5 datasets, all
  CLI-tested, self-audited clean.
- **Correction:** re-fixed the "inverted bias" framing on the chart (both over-plan, 2012 ~5×).

## Phase 6 — Network/flow discovery + order-lifecycle slice (preemptive timing)
- **Ask:** "individual item behavior across orgs at different scales … planners who control the chain — could
  they meet? hops/routes/spending double? maybe there are tables we haven't explored." Then: "are we showing
  hops / the current stage?" Then: "expected/actual per stage → preemptive maneuvers (skip/cancel/resize) not
  just a bottleneck threshold." Then: "maybe SCD2 for history — necessary or over-engineered?"
- **Discovery (metadata sweep):** found the network tables (transfer_order_receipt/shipment,
  inventory_rebalance_*, sourcing rules, freight). **Corrected a wrong hypothesis:** 2120 is NOT a
  transfer-fed hub — it has ZERO transfers (Buy/Make leaf); **2012** is the transfer hub. Coordination signal
  verified: 99.9% of dual-org SKUs have different planners per org.
- **Decision:** "prove it as a slice first" (user chose). Honest scope: 2 real stages
  (ordered→in-transit→received), NOT a 5-gate flow (accept/putaway empty); no live feed; **no hand-built
  SCD2** (over-engineering; none exists) — reuse the historical lead-time-error table instead.
- **Correction:** `purchase_receipt_line.expected_receipt_date` is a same-day MIRAGE; real PO timing =
  `features.general_historical_purchase_order_lead_time_errors`.
- **Built:** `p1flow_transfer_stages / p1flow_po_stages / p1flow_order_stage_gold` (org-aware timing bands,
  recommended maneuver, chronic-slipper signal) — reconciled (gold slip == source slip exactly).
  `P1FLOW_BUILDLOG.md`, `D_network_flow_tables.md`, notebook mirror. **Payoff:** 76% of 2120's "expedite"
  orders are chronic-supplier problems (fix the source, not the order). Memory:
  [[mke-order-lifecycle-flow-slice]].

## Phase 7 — Consumption-surface enablement (Genie, then App)
- **Ask:** "note all our interactions/activities — Genie will need to do the same via AI over this data";
  "Genie should know what questions might be asked, based on all observed scenarios"; "these will also be part
  of Databricks App development — interactive, searchable, write-backable, approve/reject, alerts."
- **Built (design, not deployment):** `GENIE_ENABLEMENT_NOTE.md` (data surface + reasoning playbook + build
  recipe), `GENIE_QUESTION_BANK.md` (every scenario → questions + guardrail Q&A), `APP_ENABLEMENT_NOTE.md`
  (read-signal → App action mapping, Lakebase entities, safe write-back path). Memory:
  [[mke-genie-app-enablement]]. Three surfaces: dashboard=show, Genie=ask, App=act.
- **Ask (this entry's trigger):** "after every acceptable work, log it, so history isn't lost." → created
  this WORKLOG.md as the standing decision journal.

---

## Phase 8 — Decision-first dashboard redesign (pages 2/3/4 + money tile)
- **Ask:** "Can we not show something more… how will this make anyone understand! What ways can these be
  re-shown; what new things make great impacts!" + "think!!!" (on screenshots of pages 2/3/4).
- **Diagnosis (honest):** page 3 Exception Queue was **BROKEN** (bound to full wide table → on-plan items on
  top, 7×-per-item repeats); page 4 Drill-down **dead-on-arrival** (SKU default "All" → 28k-SKU crush); page 2
  showed the **outlier-inflated mean** ("140% bias"). Root problem: showed *data*, not *decisions*.
- **Decision:** user chose "decision-first, all 3 pages." Rebuilt around what a planner/manager must DECIDE.
- **Built (verified numbers, all reconciled):** 6 new datasets; Page 2 = SLA scorecard (MAPE 2012 124% /
  2120 37% vs <15%) + over/under/on-plan area + ABC median; Page 3 = Monday Action List (cost-ranked, 1
  row/item, exception_type + Systemic-vs-one-off root flag) + $-by-type bar + KPIs; Page 4 = default worst
  SKU + plan-vs-actual gap + flows; Overview = **Money at risk** ($662M stockout-risk vs $843M excess capital
  @2012). Deployed + published same ID `01f1a50aed891d5c85b5e64b2c3c5d5b`. Log: RUNG2_BUILDLOG.md.
- **Guardrail added to memory (user):** NO real Oracle write-back ever — simulate in sandbox when we reach
  the action stage. ([[mke-project-guardrails]] updated.)
- **Follow-up:** user to confirm render in browser (CLI proves structure+data only).

## Phase 9 — Close the in-scope-but-unshown dashboard gaps (page 7)
- **Ask:** "Work on the IN-SCOPE but NOT YET SHOWN on the dashboard (the real gaps)" → "add these."
- **Feasibility-probed first** (won't build on absent data): confirmed `rung2_planned_weekly` has 8 snapshots
  covering shared target weeks (enables UC5/2.4.1); MoM only 2 months; root-cause still needs the ledger.
- **Built page "7 · Plan Changes & Timing":** plan-evolution-across-snapshots multi-line (UC5/2.4.1 must-have)
  + biggest-plan-revisions table + month-over-month (2.3.2, labeled thin) + receipt-timing M4 by lane×org.
  4 new datasets CLI-tested, page audit-clean, deployed+published same ID. Dashboard now 8 pages.
- **Honest scope note:** 2.3.7 five-category root-cause remains DEFERRED (needs inventory_material_transaction);
  page 3 keeps the symptom proxy, not faked. Render to be confirmed in browser.
- **Also this session:** confirmed a PRIOR pipeline build exists in the workspace (redkeychain-actuals-customer
  + rk_actual_sdp + paused rk_actuals_weekly job) — user said set it aside for now; not built upon.

## Phase 10 — Drill-down real fix + global-filter binding audit
- **Ask:** page 4 "show this in a better way, more explainable, supporting info" → then "verify Global filter
  is attached to all required/connected widgets, wherever applicable."
- **Page 4:** found the default-SKU bug I had wrongly claimed fixed — key was `defaultSelections` (plural);
  Lakeview wants `defaultSelection` (singular) → filter defaulted to "All" → 28k-SKU overlay. Fixed +
  rebuilt page to teach (how-to-read caption, 2 reactive KPIs, plan-vs-actual line, dollarized gap bar,
  flows, week-by-week evidence table). Verified singular key in deployed JSON.
- **Global filters:** audited by READING each canvas dataset's real output columns vs filter field names.
  Found the **Org filter silently dead on pages 2/3/5/7** (datasets output `org`, filter binds
  `organization_code`). Fixed: surfaced raw `organization_code` in every filterable aggregated dataset (kept
  `org` alias so widgets unbroken); 3 CTE datasets needed it at the outer select. Result: Org binds on pages
  1,2,3,4,6,7; page 5 left intentionally global (compare-all-orgs). Widget audit clean; deployed+published.
- **Lesson reinforced twice:** CLI proves structure+data but NOT selection behavior or filter reach — must
  verify render + read real output columns (substring-on-SQL lies on aliased sources).

## Phase 11 — 4-month reload, prior-week baseline, root cause (2.3.7), week slider
- **Asks:** "load 4 months, store the query in a notebook, reflect in all dashboards"; "2.3.7 root cause —
  go for it, are you stuck?"; "what will doing both do?"; "are joins inflating / granularity issues?";
  "add a weekly slider, global, in dashboard".
- **4-month widen:** rebuilt rung2 gold over 16 weeks (590,275 rows); stored runnable workspace notebook
  `rung2_actuals_build` (closes the reproducibility gap — rung2 was tables-only before). MoM now 4 months.
- **Prior-week baseline (doc §5.1):** the widen exposed an inconsistent lookback in the old earliest-snapshot
  pick; changed to nearest-snapshot-before-target → uniform 7-day lookback. Approved by user.
- **Integrity (user challenge):** re-verified at 4-mo — dim_series 1:1 (no inflation), grain clean, 2120
  double-count guard holds, on-hand not fanned. All PASS.
- **Root cause 2.3.7:** proved with evidence the ledger covers PLANT orgs only (not DC 2012/2120). Built BOTH
  lenses: rootcause_dc (per-signal, residual 80%→41%) + rootcause_plant (true ledger 5-cat, upstream tier).
  Surfaced as page-3 DC tile + page-7 labeled plant-movement tile (never summed).
- **Week slider:** global range-slider on week_start added; deployed+published. Dashboard datasets = 25.
- **Follow-up logged:** p1flow_* still on old 8-week window — re-widen when flow tiles need it.

## Phase 12 — Money-at-risk counters not org-reactive (fix)
- **Ask:** user noticed the two overview Money-at-risk counters do not change when Org filter changes; "by design?"
- **Answer:** no, a bug. They read a GROUP-BY-org dataset (ds_money_risk) which a field-based filter can't
  auto-WHERE. Fixed by repointing to raw ds_pva + derived stockout_gap_dollar/excess_capital_dollar cols;
  now Org filter + week slider both reach them. Values higher because gold is now 4 months. Deployed+published.

## Phase 13 — Deeper page 2 (FVA + bias + lead-time + MAPE trend) + time-filter redo
- **Ask:** 'not satisfied with number of widgets / limited story — anything else impactful?'
- Added 4 verified planning-quality stories to page 2 (3→12 widgets): **Forecast Value Add (NEGATIVE both
  orgs — planning worse than naive)**, correctable-bias worklist (~26%), accuracy-by-lead-time (short-lead
  slips most, counterintuitive), MAPE-trend-vs-15%-target.
- **Time filter redone (user caught my broken slider):** range-slider on a DATE with no MIN/MAX was
  misconfigured; user reframed to a numeric weeks-lookback slider — built correctly (weeks_ago rank + MIN/MAX
  bounds). Kept date-picker too; parameterized aggregated datasets so both controls filter them. Deployed.
- All datasets CLI-tested, audits clean. Render = browser gate (slider must show 1–16, not epoch).

## Phase 14 — Page 4 drill-down rebuild (dead-lines fix + richer story)
- **Ask:** page 4 shows 'dead lines' (single SKU) + 'Render more data' (All); too few widgets; better visuals.
- **Root cause:** charts were disaggregated:true on raw 590k-row ds_pva. Fix: per-SKU WEEKLY-aggregated
  ds_drill_sku (:sku + :wk params), default SKU 48111850 (rich, not near-zero 377120).
- Rebuilt 3→10 widgets: KPIs, plan-vs-actual+SS line, gap-$ bar, flows, weeks-of-cover trend (new),
  cumulative drift area (new), evidence table. CLI-tested clean; caught+fixed MAX(ABS()) counter. Deployed.

## Phase 15 — Replace unreadable plan-evolution spaghetti (page 7)
- **Ask:** first chart on page 7 'good but I don't understand it' (26 overlaid target-week lines).
- Replaced with two readable charts: **plan nervousness** (net revision % per week, bar) + **plan
  convergence** (avg |revision| by weeks-to-target, funnel line). Both org-aware, CLI-tested, deployed.
  Detail table kept. Story now readable in 2 seconds: do our plans stabilize as they firm up?

## Phase 16 — Page 4 field-based (All + org/time reactive)
- **Ask:** SKU picker needs 'All'; page must change with Org + timeline.
- **Cause:** param-based SKU picker (a param needs one value → no All; global filters can't reach a
  parameterized dataset). Fix: raw ds_drill_field + charts SUM-by-week (disaggregated:false); field-based
  SKU single-select (blank=All); wired org/slider/date-picker to it. All reactive now. Deployed.

## Phase 17 — Monday Cockpit (page 0): the action surface (roadmap step 1/3)
- **Ask:** 'I look at the overview Monday and derive nothing — I wish it told me the impact / raised a flag /
  told me what to do.' + 'next level!' + roadmap: Dashboard now -> stable pipeline -> App (keep logging +
  learnings).
- **Built:** new FIRST page '0 · Monday Cockpit' — what-changed KPIs (2,243 newly red=$23.7M this Monday),
  ranked verb action list (Expedite/Defer-cancel/Fix-supplier + systemic flag + planner), action-mix bar,
  new-exposure-by-org. Plus a what-changed delta strip on page 1 (honored all 3 sub-options user chose).
  ds_cockpit_change + ds_cockpit_actions CLI-tested, audit clean, deployed.
- **What I learned:** a LEVEL reads as 'just another chart' (barely moves WoW, no trigger). Action needs the
  DELTA + a VERB + $ + systemic flag. Design rule now: operational pages open with 'what changed & what to
  do'; analytics are the drill-down 'why'.
- **Next (roadmap):** step 2 = stable SDP+Job pipeline; step 3 = the App (clickable actions, Lakebase,
  simulated writeback). Not this pass.

## Phase 18 — Monday Cockpit: 4 additional KPIs (different-axis)
- **Ask:** 'add something more / additional KPIs?'
- Added net-exposure-swing (+$4.44M worse), top-10 concentration (20.1%), %systemic (2.8%), excess-capital
  ($113.5M) as a 2nd KPI row on page 0. All verified/audit-clean/deployed.
- **Learned:** a new KPI earns its place only if it changes a DIFFERENT decision than the existing ones —
  direction / tractability / targeting / opposite-tail here. Name the decision before adding; else it's noise.

## Phase 19 — Cockpit filterable (Org + ABC + week-replay)
- **Ask:** 'can the cockpit be filtered?' (+ 'what is ABC in business terms?' — answered: value-based Pareto
  tiering, A=vital few $268M / D=long tail).
- **Found:** cockpit reacted to NOTHING (my caption was wrong; fixed). Reworked 3 cockpit datasets to rank
  the FILTERED weeks for this/prior (week-REPLAY, verified <=08-10 -> 08-10/08-03) + :wk param; exposed
  org/abc; wired f_org(all3)/f_abc(actions)/f_week(all3). Weeks-ago slider deliberately not wired.
- **Learned:** delta pages need period logic relative to surviving rows (not hard MAX) -> filtering becomes
  replay; and match each control's semantics to the page (don't wire every filter everywhere).

## Phase 20 — Cockpit supporting visuals (story behind the numbers)
- **Ask:** 'cockpit is just numbers — where are the supporting visualizations? a number gets attention but
  "what do I look at now" is limited.'
- Added 4 because-visuals on page 0: new-exposure TREND (reframes $24M as normal vs the $509M Jun-15 spike),
  newly-red $ BY PLANNER (routing), action-mix OVER TIME (is it worsening), AGING (9,102 festering 6+ wks).
  All CLI-tested/audit-clean/deployed.
- **Learned:** a KPI is a hook not an answer — pair each headline number with the ONE visual answering the
  question it provokes (normal? who? worsening? fresh/chronic?). Number without its because-visual = 'now what?'.

## Phase 21 — Page 7 Org filter + explained the nervousness/convergence charts
- **Ask:** attach page 7 to filters; also explain the first two charts.
- Wired f_org to the 5 DC-org tiles; left plant-movements + time controls full-span BY DESIGN (different org
  universe / need full horizon). Caption corrected. Deployed.
- Explained (verbally) the two hardest charts: NERVOUSNESS = net revision per target week (2012 over-plans
  then walks down); CONVERGENCE = does weekly revision shrink as the week nears (2012 never funnels to 0 =
  chronically unstable). Both tie to the negative-FVA finding = plan over-optimism/instability.
- **Learned:** 'attach to filters' isn't wire-everything — match filter to dataset grain/org-universe; a
  filter that blanks or distorts a chart is worse than no filter. State what reacts in the caption.

## Phase 22 — Complete filter coverage (robust :param) + in-dashboard help
- **Ask:** 'not all filters reach all widgets' + 'put these details in the dashboard simply'.
- Audited all 8 pages; closed the gaps with the (all)-sentinel :param pattern so Org truly reaches all
  meaningful DC tiles (cockpit visuals, page-2 analytics, page-3 rootcause, page-1 net-trend) — CLI-tested
  both ways. Left Cross-Org/plant/top-N NONE by design.
- Added a 'How to use this dashboard' panel (plain-language filter guide + page roles + ABC meaning) and
  per-chart 'How to read' lines under the 8 hard charts.
- **Learned:** filter reach is a per-dataset contract (output-the-field + not-GROUP-BY, else param with
  (all)-sentinel); match filter to page semantics; audit by reading widget-dataset vs filter-bindings.

## Phase 23 — REGRESSION FIX: dashboard blanked (scalar param on multi-select filter)
- **Ask:** 'where did my data go? what change impacted this; resolve it + ensure functionality not broken.'
- **Data intact** (gold 590,275 rows verified first). Cause: bound a scalar (all)-sentinel STRING param to
  f_org which is a filter-MULTI-select -> invalid ARRAY-vs-scalar binding -> broken global filter blanked
  every tile. Fixed: MULTI param + (size()=0 OR array_contains(...)) + empty-array default on 13 datasets.
  Verified both ways; ALL 40 datasets return rows at default. Deployed.
- **Learned:** param complexType MUST match the filter widget (multi-select -> MULTI array + array_contains +
  empty default; single -> scalar). A bad param binding on a GLOBAL filter blanks the WHOLE dashboard, not
  just one tile. New gate: run 'every dataset returns rows at default params' before every publish.

## Phase 24 — Page-4 flat lines fixed + dashboard-wide multi-y sweep
- **Ask:** 'first two charts on page 4 still dead lines — thought we resolved it.'
- Separate bug from the filter regression: p4_line/p4_flow had MULTIPLE y-fields (multi-y line collapses).
  Rebuilt as long-format single-y + color(series) datasets (ds_drill_onhand_long/flows_long), wired to
  org/week/SKU filters. SWEPT all line/area charts -> 0 multi-y remain. All 42 datasets return data. Deployed.
- **Learned:** apply the multi-y rule PROACTIVELY — sweep every line/area for >1 y-field before publish, don't
  wait to be caught chart-by-chart. Added to pre-deploy gate alongside the 'every dataset returns rows' check.

## Standing practice (do this every time)
After each accepted deliverable, append: **date · the ask (user's words) · decision & why · artifacts
(paths/IDs) · evidence/reconcile result · corrections · follow-ups.** Keep build-mechanics in the relevant
BUILDLOG; keep intent/decisions here. Memory files hold the durable cross-session facts.

**Backups:** after appending an entry, copy this file to `worklog_backups/WORKLOG_<YYYYMMDD_HHMMSS>.md` so
the history survives an accidental overwrite/delete of the single root file. The `worklog_backups/` dir is
append-only, timestamped snapshots — never edited.

## Phase 25 — SDP pipeline (roadmap step 2): parallel build, clone dashboard, thin queries
- **Ask:** "go ahead with the SDP path — clone the dashboard, write into a NEW set of tables so I keep the
  working dashboard + its data; create an SDP pipeline that materializes ALL datasets (silver, gold,
  aggregates, views) so the dashboard runs SIMPLIFIED queries and gets the same outcome." + "do aggregations
  FIRST so the dashboard doesn't lag at scale — challenge me but make it better." + "no hardcoded data — build
  from what we have" + "are we sure we have all the data?" + "log the test cases and queries too."
- **Decision & why:** built a PARALLEL Lakeflow SDP pipeline `p1_actuals_sdp` (serverless, triggered) writing
  35 MVs to `sandbox_operations.po_management.sdp_*` — never touching the live rung2_*/p1flow_* tables or the
  working dashboard (safety net). Layers: 4 silver + 3 gold (source-equivalent to the existing builds, read
  live from prod — zero literals) + 28 per-widget-grain serving aggregates. Cloned the dashboard to thin
  queries over the serving tables. Cadence = WEEKLY triggered batch (NOT streaming/daily): the plan grain is
  weekly (Monday snapshot); MVs over batch facts per the skill decision tree. The App (step 3) is the
  real-time surface via Lakebase — different clock, not this pipeline.
- **Artifacts:** pipeline `p1_actuals_sdp` id b6f16cf7-b17e-4b08-beaa-6c8e7fb97585 (35 MVs);
  Job `p1_actuals_weekly_sdp` id 418760739520160 (Mon 07:57 CT, PAUSED, on_failure email);
  clone dashboard "P1 Actuals — SDP (Rung 2)" id 01f1a5371959178aa137d5551347afff (published);
  source `workspace_assets/p1_actuals_sdp.sql` (+workspace mirror), `rung2_dashboard_sdp.json`,
  `SDP_THIN_QUERY_MAP.md`, `SDP_VERIFICATION_LOG.md` (all test queries+results), `P1_STATUS.md` (gap scorecard).
- **Evidence/reconcile:** sdp gold == live gold EXACT — 590,275 rows, per-org row/net-$/red diffs all 0;
  planned_weekly 16,464,696 identical; newly-red 2,243/$23.72M and FVA −3.7%/−11.2% identical to live;
  DQ 4 EXPECT constraints 0 violations, org_plan_pairs=2; pipeline 0 ERROR events. Perf gate: overview/KPI
  serving tables 2–160 rows (was 590,275 live → ~18,000× cut). 42/42 clone datasets return rows at default;
  0 multi-y, 0 binding breaks. Originals intact (rung2 gold still 590,275; original dashboard ACTIVE/unchanged).
- **Corrections:** (1) rootcause_plant had no saved build SQL → re-DERIVED from inventory_material_transaction
  + location_scd1; reconciled to 99.95% (residual = the "PO Receipt Adjustment" label boundary; chose
  adjustment-first). (2) ds_sla referenced organization_code but serving MV outputs `org` → fixed. (3) User
  caught the OVERVIEW page still scanning raw 590k (its counters/bars aggregate in-widget); built
  sdp_agg_overview cube (626 rows), repointed 9 additive tiles, kept c_bias(AVG)/c_items(COUNT DISTINCT) on
  raw (widget can't reconstruct from a rollup); a per-cell ROUND caused a $9-on-$2.5bn drift → stored
  full-precision, round at display → diff now exactly 0.
- **Learned:**
  1. **Pre-aggregate to per-WIDGET grain, and store ADDITIVE COMPONENTS, never pre-divided averages.** MAPE/SLA
     store sum_abs_var_pct + cnt; the thin query does SUM/SUM over picked weeks → exact AVG, tiny scan. This is
     the mechanism that makes "aggregate-first" both fast AND bit-exact.
  2. **A Lakeview counter/bar does ONE aggregation over one field** — so COUNT DISTINCT and weighted-AVG tiles
     CANNOT be served from a rollup; they must read a raw (narrow) dataset. Know which measures are additive
     before you pre-agg. Not every tile can be collapsed to 32 rows, and that's correct, not a failure.
  3. **Never ROUND inside a serving/pre-agg table.** Rounding per-cell then re-summing drifts vs the base fact
     (here $9 on $2.5bn). Keep full precision in the cube; round only at display.
  4. **A pipeline is the place to MOVE computation, not add data.** The SDP layer introduced zero new source
     reads — same prod tables the live dashboard already used; it just materializes the heavy joins/windows once.
  5. **Weekly batch vs real-time is a per-SURFACE choice.** Analytics (weekly plan) = batch MVs; App
     interactions = Lakebase real-time. Match freshness to the signal's actual change rate; don't stream a
     weekly fact.

## Phase 26 — Widen to 180-day backfill (doc D4/P4) + make the window ONE KNOB
- **Ask:** "do the 180-day load from the pipeline AND in both dashboards" + "if changing the date is so
  tedious, there needs to be a better way!" + "why were we running p1flow?"
- **Decision & why:** requirement doc D4/P4/O10 = backfill 180 days (~26 weekly snapshots), do not exceed.
  Cutoff = 2026-03-02 (clean Monday, ~175d, under the 180 cap). Widened BOTH stacks so they stay identical:
  SDP pipeline (sdp_*) AND the original rung2_*/p1flow_*/rootcause_plant. **Root-caused the tedium:** the
  window was 7 hardcoded literals across 3 files. Refactored the SDP SQL so the window lives in ONE place —
  pipeline `configuration` keys (p1.pd_lo/pd_hi/wk_lo/wk_hi/ledger_hi) referenced via ${...} substitution.
  Future window change = one `databricks pipelines update --json` + full-refresh. No SQL edits, no re-upload.
  p1flow was widened because the dashboard's PO-timing / lead-time-band / chronic-slipper tiles read it; if
  left at the old 8-week window while gold ran 180d, pages would silently disagree (e.g. an item wrongly
  flagged "not chronic" because its late history was cut off). Also closed the pre-existing 8-week stale-window
  debt flagged in the build log.
- **Artifacts:** SDP config knobs set on pipeline b6f16cf7; parameterized `p1_actuals_sdp.sql` (${p1.*});
  widened `rung2_actuals_build.sql` + `p1flow_order_lifecycle.sql`; both dashboards' default f_week lower
  bound 2026-05-11 → 2026-03-02 (11 param defaults each); redeployed+published both (ids 01f1a50a… original,
  01f1a537… SDP clone).
- **Evidence:** SDP full-refresh COMPLETED via config knob; sdp gold 924,987 rows, 25 weeks, 2026-03-09→08-24,
  DQ 0 violations, cube 980r (perf holds). Original tables rebuilt: planned 28,799,124 / actuals 3,775,148 /
  gold 924,987. **Equivalence at 180d EXACT: rung2 gold == sdp gold (924,987), per-org row/net-$/red diffs all
  0.** Clone thin queries at new default: 25-week rollup, SLA 2 rows, cockpit newly-red 2,236 latest week.
  (Gold starts 2026-03-09 not 03-02 because prior-week baseline needs one preceding snapshot — correct.)
- **Learned:**
  1. **A load window must be ONE knob, not N literals.** Put it in pipeline `configuration` and read via
     `spark.conf`/${...}. If a "small" change touches many files, that's a design smell — fix the root, don't
     grind through the edit. (User was right to push.)
  2. **Widen the WHOLE dependency set together.** Supporting tables (p1flow timing, chronic signal) must share
     the same window as the core fact, or the dashboard tells a self-contradictory story across pages.
  3. **"Newly-red" is boundary-sensitive** — widening the window can shift a few items between newly-red vs
     already-red at the edge; the latest-week action count stays stable (~2,240), which is what's operational.
  4. **The doc's 180d is a CEILING** ("do not load beyond"); data supports back to 2025-06-28 (14mo) if ever
     needed, but we honor the cap.
  5. `CREATE OR REPLACE` is atomic — a client-side timeout on a heavy rebuild does NOT corrupt the table (it
     keeps the old data until the new one commits). Run heavy rebuilds as background tasks; poll the table, not
     the client.

## Phase 27 — Genie Space (NL Q&A over the SDP tables), record-pinpointing
- **Ask:** "before the App, I want the Genie Agent done." + "should pinpoint to the exact/set of records the
  question is about" + "include actual-vs-planned tables/questions." Decided (via AskUserQuestion): a Genie
  SPACE (not custom agent), grounded on gold fact + key serving tables, tuned for BOTH planner & manager,
  default = always show records + total.
- **Decision & why:** Genie Space is fit-for-purpose for read-only NL Q&A now (no code, governed, fast);
  wrap in a ResponsesAgent later only when the App needs tool-calling. Grounded on 5 sdp_* tables so the
  record-level drill always exists: sdp_plan_vs_actual (the item×org×week fact — record answers),
  sdp_agg_scorecard (org KPIs), sdp_exceptions (ranked worklist + chronic flag), sdp_order_stage_gold (PO
  timing + chronic supplier), sdp_rootcause_plant (upstream tier). Reused the existing GENIE_ENABLEMENT_NOTE
  (Parts C/D reasoning rules) + GENIE_QUESTION_BANK (7 parts incl. Part 1 plan-vs-actual + Part 7 guardrails),
  retargeted from rung2_/ds_/p1flow_ to sdp_*.
- **Artifacts:** `data_understanding/workspace_assets/genie_agent.json` (5 tables, 8 sample questions, 15
  example SQLs, 1 merged text_instructions). Space "P1 Actuals — Supply Plan vs Actual (SDP)" id
  **01f1a542c3f7132681b64d8ff08b4033**. Generator `/tmp/gen_genie.py`.
- **Record-pinpoint design:** text_instructions rule "ALWAYS SHOW THE RECORDS BEHIND A NUMBER" + every
  example SQL returns item_id/item_description/organization_code/week_start ranked by $ (LIMIT 50-100).
  Plan-vs-actual leads (planned_pab vs actual_end_on_hand, planned_sales_orders vs actual_shipped,
  actual_po_received; variance abs/pct/$).
- **Evidence (Conversation API):** (1) "off-plan items this week ranked by $" → returned named SKUs w/ $
  (369229 M18 Combo −$8.8M, 369722 −$2.6M, …), correct table/week/rank. (2) GUARDRAIL "on-hand value by org"
  → Genie used week_start=MAX(week_start), did NOT sum across weeks (avoided the 5.48× trap). (3) "compare
  bias 2012 vs 2120" → both over-plan 74.0% vs 28.8%, green 39.9% vs 65.5% — EXACT match to sdp_agg_scorecard,
  framed correctly (not "inverted"). All 15 example SQLs CLI-tested return rows before creation.
- **Learned:**
  1. **Grounding for "pinpoint to records" = ground on the FACT, not only the pre-agg serving tables.**
     Aggregated tables lose the item keys; the item×org×week gold keeps them, so any total drills down. Teach
     the pattern via example SQLs that all return keys+rank — Genie generalizes it.
  2. **Guardrails as instructions + examples actually work** — the "never sum on-hand" rule survived a
     naive-phrased question ("total on-hand value by org") because both the text rule and an example modeled
     MAX(week_start). Instruction alone is weaker than instruction+example.
  3. **Reuse beats regenerate** — the enablement note + question bank (written earlier for this exact moment)
     made the build a retarget, not a fresh design. The prior "note everything for Genie" work paid off.
  4. Space JSON format gotchas (skill): 32-hex ids unique across all 3 lists; tables+example_sqls sorted;
     text_instructions must be exactly ONE merged item; text fields are arrays.

## Phase 28 — Genie ↔ Dashboard link + action chips + test evidence
- **Ask:** test Genie on anti-patterns / all scenarios / P1 requirement Qs / action Qs (cancel, alert
  planner) / "mirage data"; then attach Genie to the dashboard; then (a) capture evidence + (b) add chips.
- **Did:**
  - **Attached Genie to the SDP dashboard** via `uiSettings.genieSpace` {isEnabled, overrideId
    01f1a542c3f7132681b64d8ff08b4033, ENABLED} — "Ask Genie" button now on dashboard 01f1a537…; verified on
    the deployed dashboard (not just local JSON). Theme preserved. Legacy dashboard intentionally NOT linked
    (Space is grounded on sdp_*). Genie is linked, NOT a widget (no assistant widgetType).
  - **Added 3 action starter chips** + 2 example SQLs (cancel/defer overstock, alert-planner-by-new-$),
    CLI-tested (100 / 20 rows), pushed via `genie update-space`. Space now 11 sample Qs, 17 example SQLs.
  - **GENIE_TEST_EVIDENCE.md** — captured every validated Q&A (per-item, anti-patterns, scenarios, P1
    UC1-UC6/M1-M5, action decisions) with Genie's actual answers + verdicts.
- **Evidence highlights (all ✅, records returned):** off-plan-by-$ named SKUs (369229 −$8.8M); AP-1 refused
  cross-week on-hand sum (used MAX week); AP-5 ranked by stockout_risk_usd not unit-miss; bias 2012 74.0% vs
  2120 28.8% (exact scorecard); "cancel?" → M18 RL HO XC5 $8.4M excess + specific POs; "alert?" → Bartholf,
  Nick $1.69M; "mirage?" → correctly recalled expected_receipt_date same-day mirage + on-hand-sum +
  raw-$ org compare.
- **Learned:**
  1. **Genie attaches to an AI/BI dashboard via `uiSettings.genieSpace`, not as a widget** — one JSON block
     + redeploy. Gives an in-dashboard "Ask Genie" without leaving the page (charts for the eye, Genie for
     the follow-up).
  2. **Genie can REASON to an action recommendation (cancel this PO / alert this planner) but cannot EXECUTE
     it.** That's the clean line between Genie (what/why/who) and the App (do it) — worth stating to the team
     so expectations are right.
  3. Guardrail knowledge (the "mirage" answer) transfers through text_instructions — Genie can tell you what
     data to distrust, which is a genuinely useful data-literacy feature, not just Q&A.

## Phase 29 — P1 Actions App (roadmap step 3): built, deployed, data-loaded, verified
- **Ask:** the actionable App — see off-plan → ask why → forecast/what-if → approve → live cascade →
  audit → simulated Oracle push. Plus (user, mid-build): chat + agentic tool-calling; ai_forecast what-if
  ("what if I cancel"); capture recommended-vs-final + reason → MLflow eval dataset; creative action verbs;
  actions in Lakebase, dashboard live-refreshed, publishable to Delta; modern/interactive UI; the app must
  TEACH the business (not assume); put the dashboard + a scenarios storytelling page in the app.
- **Built:** NEW Lakebase project `mke-po-actions` (6 existing untouched); AppKit app (lakebase+analytics+
  genie+agents) deployed & RUNNING at https://mke-po-actions-4482605715640778.18.azure.databricksapps.com;
  schema `app_po` (mirrors + ONE writable action_request + audit + SIMULATED integration_outbox/result +
  decision_eval + chat + FTS/pg_trgm search); propose→approve→execute transaction (OBO, audit, sim-push);
  7-tool agent (ask_data/find_record/forecast_item/what_if/rank_actions/draft/execute, effect:'destructive'
  → HITL gate); ai_forecast what-if (VERIFIED signature: horizon=end-date, time_col=timestamp, value_col=
  double); polished cockpit (echarts forecast, semantic KPIs, what-if cards, decision capture, live flash).
  Validates clean; deployed via DAB.
- **Bugs hit & fixed (the hard part):** (1) hand-rolled SQL-Statements fetch with DATABRICKS_TOKEN — Apps
  don't inject a token; rewired to appkit.analytics.query (SP credential chain). (2) DATABRICKS_HOST had no
  https:// scheme → URL parse error; normalized. (3) app SP INSUFFICIENT_PRIVILEGES on
  sandbox_operations.po_management — catalog owned by group red-keychain-workshop; I lack MANAGE + not ws
  admin, so couldn't GRANT USE CATALOG or add SP to the group. **Resolution = the RIGHT architecture:** load
  the Lakebase mirrors from MY creds (superuser on the project I created) via psql; the app then reads ONLY
  its own app_po tables and never needs catalog access. Loaded 2,516 exceptions / 62,211 trajectory / KPI
  ($91.2M, 208 chronic, 64 planners). Hero item 48111881X M18 Forge XC8.0 Battery $3.07M.
- **Verified:** queue join returns ranked real items; simulated execute → resolved KPI math works (cascade
  sound). Core loop proven at the data layer.
- **What the user (rightly) called out & still open:** app looked empty (data now loaded — fixed); leftover
  scaffold Dashboard tab shows fake "Sales Trend/hello world" (must replace with our data); app assumes
  domain knowledge — needs self-teaching context strips + metric explainers + a scenarios storytelling page.
- **Learned:**
  1. **Databricks Apps auth: never hand-roll a token.** Use appkit.analytics.query / appkit.lakebase.query —
     they carry the SP credential chain. A raw DATABRICKS_TOKEN doesn't exist in the Apps runtime.
  2. **App SP catalog access is a governance boundary you may not control.** If the source catalog is owned
     by a group you can't manage, don't fight it — load the Lakebase OLTP mirrors from an authorized identity;
     the app reading only its own OLTP plane is the cleaner two-plane design anyway.
  3. **Deploy-first is real** — the SP must own app_po (it did: schema created, FTS+trgm caps true).
  4. **An empty app reads as broken even when the architecture is sound.** Load real data + kill scaffold
     BEFORE showing it. And an operational app must teach its domain, not assume it (user's core critique).

## Phase 30 — App polish + true-agentic explain + FTS search + full write-back, all verified on the DEPLOYED app
- **Asks (this session):** make the FrontEnd dashboards work; on click, an LLM explains everything about the
  item AND recommends order/reject/etc.; ensure Lakebase search works; confirm all Lakebase write-backs work;
  and make the app self-teaching / business-ready.
- **Dashboard (native) fixed:** the AppKit data-mode `BarChart` rendered axes but no bars with our JSON. Root
  cause: data-mode bar series didn't bind. **Fix = a deterministic CSS `Bars` component** (label · scaled bar ·
  $-formatted value) — replaces BarChart for the 3 bar cards; `PieChart` (systemic vs one-off) kept (works).
  Screenshot-verified: $ by ABC (A=$63.9M), by-planner (Rowe $9.2M → Shah $2.1M), by-$ band ($100K–1M=$46.5M),
  pie 91.6% one-off. Every card has a teaching caption. Closes "dashboards on the FrontEnd not working".
- **True-agentic explain-on-click:** new `/api/po/explain/:itemId`. Deterministic reasoning over the REAL row
  (gap, $ risk, on-hand vs floor, chronic flag, planner) is the GUARANTEED answer (source:"rules"); an LLM
  path via the AppKit `serving('llm')` plugin is tried first and gracefully falls back (runtime type-guard
  `hasServing`, not a cast — passes appkit lint's no-double-type-assertion). Output includes a narrative +
  a recommended_action (EXPEDITE / FIX_SUPPLIER / REVIEW / …) + recommended_qty + confidence + reason. The
  cockpit DetailDrawer auto-runs it on open (Sparkles panel), shows the explanation + a recommendation badge,
  and PRE-FILLS the chosen action + qty. Verified on deploy: 48111881X → "M18 Forge XC8.0 Battery, ABC A,
  50,336 u below floor, $3.07M risk, one-off, planner Rowe" → **EXPEDITE 50,336 / medium**.
  (Honest state: it's the rules engine today — the `serving` resource isn't wired into this app; the LLM path
  is ready and will engage once a serving endpoint is added + redeployed.)
- **Search: full ladder live.** On the DEPLOYED app the SP-owned `app_po` schema has the GIN full-text index,
  so `q=battery` returns **mode:"fts"** (20 ranked hits); `q=48111` uses **mode:"ilike"** (id-prefix, 12 hits).
  The FTS→trigram→ILIKE ladder degrades correctly. (Local dev instance falls to ILIKE — schema/index owned
  differently there; deploy is the source of truth.)
- **Write-back: full loop proven on deploy.** propose→execute on 48111813B: status proposed→executed,
  `approved_by` = OBO planner email, override captured (final 5,000 vs recommended 50,336 + reason), audit_trail
  = 2 events (proposed, executed) each with actor/ts/reason/tool, SIMULATED Oracle outbox+ack enqueued in one
  txn. Then `/api/po/admin/reset` restored clean demo state (resolved $0, base 2,516/$91.2M intact).
- **Deploy:** `databricks sync` → `databricks apps deploy` (SNAPSHOT) SUCCEEDED, app RUNNING. Validate clean
  (typecheck + ast-grep lint + tests). Guardrails held: prod read-only, writes only to Lakebase app_po +
  (later) sandbox_operations.po_management, Oracle SIMULATED, only the new mke-po-actions project touched.
- **Learned:**
  1. **AppKit data-mode BarChart is unreliable with dynamic JSON — a CSS bar you control always renders.**
     Pie was fine; bars weren't. When a managed component fights you, a 20-line deterministic component beats
     debugging the black box for an operational surface.
  2. **Make the deterministic answer the product, the LLM an enhancement.** The rules-based explain reasons
     over real facts and is genuinely useful; wiring the LLM is then a pure upgrade, never a dependency. Ship
     the guaranteed-correct path first, gate the model path behind graceful fallback.
  3. **The deployed app ≠ local dev for identity-scoped features.** FTS engaged on deploy (SP owns the schema
     + index) but not locally. Verify identity-dependent behavior against the deployed SP, not the dev shell.
  4. **Lint is a real gate:** `as unknown as` fails `appkit validate`. Use a runtime type guard for optional
     plugins — it's both correct and lint-clean.
- **Still open:** Phase 7 (publish executed actions Lakebase→Delta sandbox_operations.po_management.
  action_outcome_history — the NEW-18 feedback loop); optionally wire a `serving` endpoint so explain uses a
  real LLM; MLflow eval over the captured recommended-vs-final decisions.

## Phase 31 — Real LLM engine wired (both options kept: live LLM stream ⇄ deterministic rules)
- **Ask:** make the explain-on-click a TRUE LLM call (not just the rules engine), and KEEP BOTH options
  (user: "keep both options"; "live streaming outcome looks better").
- **Row-click first:** made the whole queue row clickable (violet hover) → opens the drawer; header hint
  "✨ Click any row for AI analysis + recommended action"; button relabeled Explain ▸ (stopPropagation so it
  doesn't double-fire). So a single click on any item surfaces the analysis — the requested UX.
- **Serving plugin wired:** added AppKit `serving()` plugin (alias `llm` → env DATABRICKS_SERVING_ENDPOINT_NAME)
  in server.ts; `serving-endpoint` resource (type serving_endpoint, CAN_QUERY) added to databricks.yml +
  app.yaml env; bundle deployed so the app SP has CAN_QUERY on `databricks-claude-sonnet-4-5`. Endpoint chosen
  from `serving-endpoints list` (many foundation models READY; Claude Sonnet 4.5 is the default).
- **Both engines, selectable:** `/api/po/explain/:itemId` and `/api/po/explain-stream/:itemId` now take
  `?engine=rules|llm|auto` (auto = LLM when wired, else rules). LLM path calls the real model via
  `appkit.serving('llm').invoke()`, then re-emits the answer word-by-word over SSE for the live-typing feel;
  rules path streams the deterministic text. LLM ALWAYS falls back to rules on any failure (never hard-depends).
  Drawer has an Auto/LLM/Rules toggle + Re-run; badge shows which engine produced the shown answer.
- **The prompt:** model writes 3–4 plain-English sentences, then a machine-parseable `@@REC action= qty=
  confidence= reason=` trailer (stripped from the visible stream, parsed into the recommendation). Prose-first
  streams naturally; the trailer gives structured pre-fill without JSON-in-stream fragility.
- **Verified on the DEPLOYED app (real Claude Sonnet 4.5):** engine=llm →
  "…safety stock climbing sharply over the past eight weeks (104K→194K) while actual inventory stayed flat…
  no PO receipts in the last five weeks despite ~4–5K units/week demand… imminent stockout on a critical
  battery platform…" → EXPEDITE/NEW_PO, 60–75K, high. It genuinely reasoned over the 8-week trajectory (spotted
  the SS ramp AND the zero-receipts streak) — not a template. engine=rules → deterministic one-liner, EXPEDITE
  50,336, medium. engine=auto → picks LLM. All three confirmed live via OAuth-authed curl.
- **Bug fixed:** the programmatic `serving('llm').invoke()` wraps its result in ExecutionResult `{ ok, data }` —
  reading `out.choices` directly gave empty content and silently fell back to rules. Unwrap `.data ?? out`
  first. (Also: the serving handle exposes `invoke` only, NOT `stream` — true SSE streaming is on the plugin's
  own /api/serving/:alias/stream HTTP route; server-side we invoke then re-stream. Confirmed against the
  installed AppKit types, not guessed.) Also: dev server loads `.env` (not `.env.local`) via
  --env-file-if-exists, so the endpoint env must live in `.env`.
- **Deploy:** validate clean (lint incl. no-double-type-assertion via the hasServing runtime guard; typecheck;
  tests). `bundle deploy` (one transient "failed to update app's compute size" — succeeded on retry) +
  `apps deploy`; app RUNNING with all 4 resources attached (sql-warehouse, genie-space, postgres,
  serving-endpoint). Guardrails intact.
- **Learned:**
  1. **AppKit programmatic invoke ≠ the HTTP route shape.** The HTTP `/api/serving/:alias/invoke` returns the
     raw completion; the in-process `serving().invoke()` wraps it in ExecutionResult `{ ok, data }`. Unwrap, or
     you silently get empty content. Verify the return shape from the installed .d.ts, don't assume OpenAI shape.
  2. **Keep the deterministic engine as a first-class option, not just a fallback.** Two selectable engines +
     auto gives trust (rules = reproducible, instant, auditable) AND depth (LLM = reads the trajectory, infers
     root cause). The user explicitly wanted both; it's also the safer product.
  3. **Prose + a parseable trailer beats JSON-in-stream.** Streaming raw JSON tokens looks broken mid-flight;
     prose streams beautifully and the `@@REC` trailer (held back from the visible stream) carries structure.
  4. **A row-level click is the natural "tell me everything" gesture** — gating it behind a button was the miss;
     the whole row now opens the analysis.
- **Still open:** Phase 7 (publish executed actions Lakebase→Delta action_outcome_history, NEW-18); MLflow eval
  over captured recommended-vs-final decisions; (optional) surface an in-drawer note when LLM fell back to rules.

## Phase 32 — App SP granted direct catalog access; agentic-loop unlocked (verification + analysis, no new build)
- **Context:** post-Phase-31 health check + the user reported "I just got it" (new access). No code change this
  phase — verification + architectural read-out only.
- **Health check (deployed app, OAuth-authed curl):** state RUNNING / compute ACTIVE; every endpoint 200 —
  queue, kpis, analytics/by-abc, analytics/by-planner, search(battery), forecast, explain(rules),
  scenario/chronic. App is fully working.
- **THE grant landed (resolves the Phase-29 blocker permanently):** app SP `06ae418f-5604-498d-82c9-73e413650a53`
  now has **SELECT + USE_SCHEMA directly on `sandbox_operations.po_management`** (effective shows ALL_PRIVILEGES
  inherited). Verified LIVE, not just on paper: the deployed forecast endpoint ran `ai_forecast()` over
  `sandbox_operations.po_management.sdp_plan_vs_actual` via `appkit.analytics.query` (SP chain) and returned 8
  real points (y_forecast 137,206; bounds 71,040–175,203). That query only succeeds if the SP can read the
  catalog. Catalog still owned by group `red-keychain-workshop` (ALL_PRIVILEGES) — the SP grant is additive.
- **What this unlocks (agentic-app perspective):**
  1. Tools become autonomous — the SP reads its grounding + writes outputs AS ITSELF; no human pre-load in the
     credential loop (kills the demo crutch where I hand-loaded mirrors from my superuser creds).
  2. Real closed learning loop — SP can WRITE executed decisions back to Delta (action_outcome_history), turning
     recommendation-vs-final(+reason) into an MLflow eval set; makes NEW-11 (codify planner knowledge) / NEW-18
     (feedback loop) mechanically possible. This is the capability that distinguishes an agent from a chatbot.
  3. Fresh grounding — the startup `syncFromDelta` (already coded, previously failing silently on privileges) can
     now self-sync from the live `sdp_*` tables, so the cockpit moves with the weekly SDP pipeline instead of a
     one-time snapshot.
  4. One governed identity for the whole audit chain (read fact → ai_forecast → write outcome) under UC grants +
     lineage — trustable in production, not just sandbox.
  5. Tool surface can safely expand — "publish to the analytical plane" becomes a permissioned agent verb
     (snapshot exception set, materialize decision log, emit QA evidence) inside guardrails.
- **Guardrail check:** unlock is entirely within `sandbox_operations` (the approved writable schema).
  prod_edw/prod_operations remain READ-ONLY; Oracle writeback still SIMULATED. No boundary crossed.
- **Caveat to confirm before relying on WRITES:** schema listing showed explicit `SELECT, USE_SCHEMA` but
  effective `ALL_PRIVILEGES` — slightly disagree. Before Phase 7 writes, confirm the SP can actually
  CREATE/INSERT into `sandbox_operations.po_management` (user declined to run this now).
- **Known cosmetic issue:** the Databricks Apps UI still shows a stale "Update failed 1 hour ago — Unexpectedly
  failed to update app's compute size" banner from the Phase-31 transient control-plane hiccup. The app is
  Running and the later deploy went green; a fresh clean Deploy clears the banner. Not a code bug. (User has not
  asked to clear it yet.)
- **Decisions this phase:** user explicitly declined (a) triggering a live re-sync and (b) confirming write
  capability / building Phase 7 right now. So Phase 7 + MLflow eval remain open by choice, not by blocker —
  the access that was blocking them is now in place.
- **Learned:** the governance boundary that forced the two-plane workaround (Phase 29) was never architectural —
  it was a missing grant. Once granted, the same two-plane design becomes a *choice* (OLTP write surface + OLAP
  truth) rather than a workaround, and the closed feedback loop it always implied is now buildable.

## Phase 33 — Parallel Streamlit app (functional twin of the React cockpit), independent end-to-end
- **Ask:** distill everything (the agentic-ops-app UI skill, the deployed mke-po-actions app, the whole MKE
  project), reference the Databricks Apps Streamlit cookbook + Streamlit docs, and build a PARALLEL Databricks
  App on Streamlit with the current functionality. Then (mid-build): make it independent — its own schema, its
  own ymls/deployment, its own assets end-to-end.
- **Distillation:** 3 subagents produced dense briefs — (1) the agentic-ops skill (load-bearing loop
  see→ask-why→recommend→approve→act→cascade→audit; two-plane OLTP+OLAP; one writable table; HITL gate;
  rules-first-LLM-enhancement; degrade-don't-loop), (2) the full app spec (every route SQL, the app_po schema,
  the 10 action verbs, explain @@REC prompt), (3) whole-project context (P1 scope, sdp_* spine, scenarios,
  guardrails, the anchor numbers). Cookbook confirmed the Databricks-Streamlit patterns: WorkspaceClient SP
  auth, serving_endpoints.query(ChatMessage), OBO via x-forwarded-* headers, port=${DATABRICKS_APP_PORT}.
- **Built `mke-po-actions-st/`** (Streamlit multipage): app.py + 4 pages (Cockpit, Ask-Genie, Dashboard,
  Scenarios) + lib/ (lakebase psycopg w/ OAuth-token cache+refresh; warehouse databricks-sql-connector for
  ai_forecast; serving: real Sonnet-4.5 llm_explain + deterministic rules_explain + word-stream; domain: every
  READ route ported verbatim SQL; actions: propose/execute(ONE txn)/reject + decision_eval; schema bootstrap;
  identity OBO; theme). Full parity: queue, 4 KPI tiles, FTS→trigram→ILIKE search, click-row → streaming AI
  analysis with LLM/Rules/Auto engine radio + recommendation, forecast (Plotly band), what-if, decision
  capture, approve→execute write-back (audit + SIMULATED Oracle + decision_eval), analytics (Plotly bars/pie +
  teaching captions), scenarios playbook (live), Genie NL Q&A.
- **Independence (user's explicit requirement) — end to end:** own directory, own app.yaml + databricks.yml +
  bundle (`mke-po-actions-st`), own deployed app + **own Service Principal** (`d630d5ba…` ≠ React app's
  `06ae418f…`), own URL, and own Lakebase **schema `app_po_st`**. Built app_po_st as a `LIKE app_po INCLUDING
  ALL` structural clone (carried the generated search_tsv + FTS/trigram indexes + PKs), copied the mirror data
  (2,516 / 62,211 / 1) from app_po, left the writable tables EMPTY. **Write-independence PROVEN:** an INSERT
  into app_po_st.action_request is visible only in app_po_st (n=1), never in app_po (n=0); after cleanup
  app_po_st actions=0 while the React app's app_po still holds its 2. Granted the NEW SP read+write on
  app_po_st (+ read-only on app_po mirrors for the bootstrap safety net). Shared by user's choice: the Lakebase
  project compute, SQL warehouse, Genie space, serving endpoint (foundation models are workspace-shared —
  no per-app copy exists).
- **Verified live:** every ported SQL run against real Lakebase (queue top item 48111881X $3.07M; KPIs
  2,516/$91.2M/208/64; FTS 'battery' works; by-ABC A=$63.9M; execute-transaction shape via BEGIN…ROLLBACK left
  zero rows). ai_forecast verified via CLI (8 weekly points). Deployed: bundle deploy + apps deploy →
  **App started successfully / RUNNING**, HTTP 200, Streamlit clean in logs. app_po_st serves the correct
  ranked queue as the deployed SP.
- **Bugs fixed:** (1) `.venv` swept into the deploy (881 files) → added bundle `sync.exclude` + .gitignore,
  redeployed lean (25 files). (2) First app boot CRASHED: `--server.port ${DATABRICKS_APP_PORT:-8000}` was
  passed literally (Apps command list isn't shell-expanded) → wrapped the command in `bash -c` so the env var
  expands. Deps + build had succeeded; only the start command was wrong.
- **Learned:**
  1. **Streamlit on Databricks Apps needs a shell for env expansion.** A command *array* is exec'd directly, so
     `${DATABRICKS_APP_PORT}` never expands — wrap in `bash -c "streamlit run … --server.port ${…}"`. (The #1
     Streamlit-on-Apps gotcha, distinct from the React/Node path.)
  2. **`CREATE TABLE … LIKE src INCLUDING ALL` is the cleanest way to fork a Lakebase schema** — it clones
     columns, generated tsvector, indexes, and PKs in one step; then copy data (enumerate columns to skip the
     GENERATED search_tsv). An independent schema + a distinct app SP is what actually decouples two apps.
  3. **A parallel app is a portability proof.** The exact same SQL, guardrails, action verbs, rules/LLM engine,
     and write-transaction reproduce faithfully in Python/Streamlit — the *architecture* (two-plane, one
     writable table, HITL, rules-first) is framework-independent; only the UI idioms and the port/serving glue
     differ. st.dataframe row-select = the React "click"; st.write_stream = the SSE token stream.
  4. **Exclude the venv from bundle sync from the start** — otherwise the first deploy uploads thousands of
     dependency files. `sync.exclude` in databricks.yml is the fix.
- **Two apps now run side-by-side on the same data spine, fully independent:**
  React `mke-po-actions` (app_po) + Streamlit `mke-po-actions-st` (app_po_st).
- **Still open (unchanged):** Phase 7 (Lakebase→Delta action_outcome_history), MLflow eval. Not part of this
  parallel-UI pass.

## Phase 34 — Authored the `databricks-streamlit-apps` skill (build-from-scratch fastpath)
- **Ask:** create a detailed skill so another agent can build a Streamlit app on Databricks Apps from
  scratch — "that's how evolution works." Distilled from the real Phase-33 build.
- **Built** `.claude/skills/databricks-streamlit-apps/` (same shape as lakeview-dashboard-fastpath): a
  SKILL.md (iron rules + 8-step build loop + reference routing) + 7 references + 11 template files (a
  complete, syntax-checked minimal app).
  - **references/**: architecture (data-plane decision gate + two-plane OLTP/OLAP pattern),
    project-structure (lib/pages split), lakebase-connectivity (OAuth-token psycopg cache/refresh, Tx,
    FTS ladder, LIKE-INCLUDING-ALL schema fork + SP grants, psql verification), integrations (warehouse
    SQL + ai_forecast, serving LLM, invoke-then-restream streaming, Genie poll, OBO headers, discovery
    cheat-sheet), ui-patterns (KPIs, dataframe-selection-as-click, st.dialog drawer, streaming+engine
    toggle, Plotly charts, live cascade via st.rerun, required states), deploy (app.yaml+databricks.yml,
    the shell-wrap rule, sync.exclude, deploy sequence, live verification), symptom-fix (the register —
    ~18 symptom→cause→fix rows, every one hit or avoided on the real build).
  - **templates/**: app.yaml (bash -c wrapped), databricks.yml (sync.exclude + 4 resource blocks),
    requirements.txt, .gitignore, app.py, lib/{config,lakebase,warehouse,serving,identity}.py,
    pages/1_Example.py (the full see→explain→act loop). All Python parses clean.
- **The load-bearing lessons encoded (so the next agent skips the pain):** (1) shell-wrap the start
  command or `${DATABRICKS_APP_PORT}` is passed literally and the app crashes; (2) bind 0.0.0.0 + the
  injected port; (3) Lakebase password = a refreshing OAuth token, not a secret; (4) declare every
  resource with a permission so the SP is auto-granted; (5) sync.exclude the venv from deploy #1;
  (6) deploy-first (or explicit GRANT) for Lakebase writes; (7) rules-first, LLM-as-enhancement;
  (8) st.rerun IS the live cascade; (9) LIKE…INCLUDING ALL to fork a schema independently.
- **Verified:** all 11 templates syntax-check; SKILL.md frontmatter valid (name + single description);
  skill auto-registered (appeared in the available-skills list). Complements databricks-core / -apps /
  -lakebase / -genie-agents rather than duplicating them.
- **Learned:** a skill authored straight from a just-shipped build is the highest-fidelity kind — the
  symptom→fix register is literally the turn-by-turn debugging of Phase 33, so the next agent inherits
  the scar tissue, not just the happy path. Evolution: each build hardens the skill that makes the next
  one one clean pass.

## Phase 35 — Hardened the Streamlit skill from the live-bug fixes (evolution loop)
- Three real bugs from running mke-po-actions-st were fed back into `databricks-streamlit-apps`:
  1. **Lakebase token-mint call.** SDK `w.database.generate_database_credential(instance_names=[endpoint])`
     is the legacy Provisioned API → 404 "Database instance … not found" on every page. Correct call is
     the Autoscaling REST `POST /api/2.0/postgres/credentials` body `{"endpoint": "<path>"}` (verified via
     `--debug`). Fixed the live app's lib/lakebase.py + the skill template + SKILL rule 4 + symptom-fix row.
  2. **New app = new SP = its own UC grants.** The Streamlit app's SP (d630d5ba…) ≠ the React app's
     (06ae418f…, granted in Phase 32); it hit PERMISSION_DENIED on sandbox_operations.sdp_* for Genie +
     forecast. Resource-permission auto-grant covers the warehouse/serving/lakebase/genie RESOURCE but NOT
     UC SELECT/USE on the tables. I lack MANAGE on the catalog → owner must grant. Encoded: SKILL rule 5,
     deploy.md "TWO kinds of grants", symptom-fix row, and the design rule to degrade catalog-dependent
     features gracefully.
  3. **st.dataframe has no whole-row click.** Row-select fires only on the left checkbox; a cell click
     does nothing → the detail dialog never opened (user caught it). Fix = explicit selectbox + "Analyze ▸"
     button opens the @st.dialog, checkbox kept as bonus. Encoded: SKILL rule 7, ui-patterns rewrite,
     symptom-fix row, and the template page now ships the picker+button by default.
- Also fixed the live app for #1 (deployed, RUNNING, mirror-backed pages recovered) and #3 (deployed).
  #2 remains pending a catalog owner's GRANT (forecast/Genie degrade gracefully meanwhile; Cockpit queue,
  KPIs, search, LLM-explain, write-back all work).
- **Learned:** the tightest evolution loop is fix-live-then-write-the-skill in the same pass — every fix
  became a rule + a symptom-fix row + a corrected template line, so the next agent never rediscovers it.
